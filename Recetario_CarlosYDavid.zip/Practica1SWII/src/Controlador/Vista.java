/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;

/**
 *
 * @author darth
 */
public class Vista extends JFrame{
    //Creamos la barra de Menu
      JMenuBar barraMenu = new JMenuBar();
 
   //Creamos los menus
      JMenu recetario = new JMenu("Recetario");
      JMenu receta = new JMenu("Receta");
      
      //Añadimos los menus a la barra de menu
      //barraMenu.add(recetario);
      //barraMenu.add(receta);
    
    
}
