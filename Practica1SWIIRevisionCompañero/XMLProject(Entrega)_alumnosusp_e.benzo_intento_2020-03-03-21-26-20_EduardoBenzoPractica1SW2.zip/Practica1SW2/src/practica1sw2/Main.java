/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sw2;


import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;


/**
 *
 * @author ebenz
 */
public class Main {
 static public void main(String[] arg) throws ParserConfigurationException, SAXException {
     Concesionario concesionario=new Concesionario();
    System.out.println ("Empezamos el programa");
    Menu menu=new Menu();
    menu.preMenu(concesionario);
 }
}

