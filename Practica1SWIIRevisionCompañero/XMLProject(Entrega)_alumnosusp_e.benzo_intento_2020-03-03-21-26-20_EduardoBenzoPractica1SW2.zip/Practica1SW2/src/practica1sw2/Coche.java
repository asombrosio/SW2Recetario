/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sw2;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ebenz
 */
@XmlAccessorType (XmlAccessType.FIELD)
@XmlRootElement(name="Coche")

public class Coche implements Serializable {
    @XmlAttribute
    private Integer id;
    @XmlElement
    private String marca;
    @XmlElement
    private String modelo;
    @XmlElement
    private String color;

    public Coche(Integer id, String marca, String modelo, String color) {
        this.id = id;
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    public Integer getId() {
        return id;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    public void añadirAConcesionario(Coche coche){
        
    }
   

   
    
    

    

   

    

   

    public Coche() {
    }

    
    
    
}
