/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sw2;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

/**
 *
 * @author ebenz
 */
public class MarshUnmarsh {
    
    public void marshallConcesionario(Concesionario concesionario){
        try {
      JAXBContext jaxbC = JAXBContext.newInstance(Concesionario.class);
      Marshaller jaxbM = jaxbC.createMarshaller();
      jaxbM.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
      
      String nombre=concesionario.getNombre();
     
      File XMLfile = new File(nombre+".xml");
      jaxbM.marshal(concesionario, XMLfile);
      jaxbM.marshal(concesionario, System.out);


      
      
      
      
    } catch (JAXBException e) {
            // TODO Auto-generated catch block

    }

    }
    
    public Concesionario unmarshallConcesionario(String nombre){
       
        try {
            
            JAXBContext jaxbC=JAXBContext.newInstance(Concesionario.class);
            
            Unmarshaller jaxbU=jaxbC.createUnmarshaller();
            
            File XMLfile=new File(nombre+".xml");
            
            Concesionario concesionario =(Concesionario) jaxbU.unmarshal(XMLfile);
            
            System.out.println(concesionario);
            return concesionario ;
        } catch (JAXBException ex) {
            Logger.getLogger(MarshUnmarsh.class.getName()).log(Level.SEVERE, null, ex);
            
        }
       return null;
        
    }
    
    
    
    public void marshallCoche(Coche coche){
        try {
      JAXBContext jaxbC = JAXBContext.newInstance(Coche.class);
      Marshaller jaxbM = jaxbC.createMarshaller();
      jaxbM.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
      Integer id=coche.getId();
      File XMLfile = new File(id+".xml");
      jaxbM.marshal(coche, XMLfile);
      jaxbM.marshal(coche, System.out);
      
      
      
    } catch (JAXBException e) {
            // TODO Auto-generated catch block

    }

    }
    public Coche unmarshallCoche(Integer id){
       
        try {
            JAXBContext jaxbC=JAXBContext.newInstance(Coche.class);
            
            Unmarshaller jaxbU=jaxbC.createUnmarshaller();
            
            File XMLfile=new File(id+".xml");
            
            Coche coche =(Coche) jaxbU.unmarshal(XMLfile);
            System.out.println(coche);
            return coche ;
        } catch (JAXBException ex) {
            Logger.getLogger(MarshUnmarsh.class.getName()).log(Level.SEVERE, null, ex);
            
        }
       return null;
        
    }}
        
    