/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sw2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 *
 * @author ebenz
 */
public class CheckWellFormedXML {
    public String  nombre;
  

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public CheckWellFormedXML(String nombre) {
        this.nombre = nombre;
    }
    
    
    public String checkWellFormed(String nombre) {
        try {
            
            /* try*/
            String path =nombre+".xml";
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            db.parse(new File(path));
            return "esta bien formado";
            
            
          
           
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(CheckWellFormedXML.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            System.out.println("no esta bien formado");
        } catch (FileNotFoundException ex) {
            System.out.println("el fichero no existe");
        
       
        
        } catch (IOException ex) {
            Logger.getLogger(CheckWellFormedXML.class.getName()).log(Level.SEVERE, null, ex);
}  
        

        return "ha habido un error";
    }

    public CheckWellFormedXML() {
        
    }
    
    
}


