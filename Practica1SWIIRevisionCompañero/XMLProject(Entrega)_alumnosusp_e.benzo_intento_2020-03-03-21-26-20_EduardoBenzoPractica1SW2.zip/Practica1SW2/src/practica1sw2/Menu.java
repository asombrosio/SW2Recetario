/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sw2;

import java.io.File;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author ebenz
 */
public class Menu {
    public void preMenu(Concesionario concesionario){
         Scanner sn = new Scanner(System.in);
         boolean salir = false;
         int opcion;
    while (!salir) {
            
            System.out.println("1. concesionario existente");
            System.out.println("2. nuevo concesionario");
            System.out.println("3. salir");
 
            try {
  
  
                System.out.println("Escribe una de las opciones");
                opcion = sn.nextInt();
 
                switch (opcion) {
                    case 1:
                        
                        System.out.println("introduce el nombre del concesionario, si quiere usar el "
                                + "concesionario por defecto, introduca `prueba`");
                        Scanner entradaEscaner2 = new Scanner (System.in);  
                        MarshUnmarsh unmursh=new MarshUnmarsh();
                        String nombre = entradaEscaner2.nextLine (); 
                        concesionario=unmursh.unmarshallConcesionario(nombre);
                        menuPrincipal(concesionario);
                        break;
                    
                    case 2:
                        System.out.println("introduce el nombre del concesionario");
                        Scanner entradaEscaner4 = new Scanner (System.in);
                        String nombre2=entradaEscaner4.nextLine ();
                        concesionario.setNombre(nombre2);
                        System.out.println("introduzca la localizacion");
                        
                        String localizacion = entradaEscaner4.nextLine ();
                        concesionario.setLocalizacion(localizacion);
                        System.out.println ("Por favor introduzca el nombre del encargado");
                        
                        String encargado=entradaEscaner4.nextLine();
                        concesionario.setEncargado(encargado);
                        menuPrincipal(concesionario);
                        break;
                        
                    case 3:
                        salir = true;
                        break;
                    default:
                        System.out.println("Solo números entre 1 y 3");
                }
            } catch (InputMismatchException e) {
                System.out.println("Debes insertar un número");
                sn.next();
            }
        }
        
    }
    public void menuPrincipal(Concesionario concesionario){
     Scanner sn = new Scanner(System.in);
     ArrayList<Coche> coches =concesionario.getCoches();
        boolean salir = false;
        int opcion; //Guardaremos la opcion del usuario
 
        while (!salir) {
 
            
            System.out.println("1. menu coche");
            System.out.println("2. validar con dtd");
            System.out.println("3. validar con XSD");
            System.out.println("4. introducir sentencia xpath");
            System.out.println("5. introducir sentencia xquery");
            System.out.println("6. chequeo bien formado");
            System.out.println("7.guardar concesionario");
            System.out.println("8.Salir");
            
 
            try {
  
  
                System.out.println("Escribe una de las opciones");
                opcion = sn.nextInt();
 
                switch (opcion) {
                    
                        
                    case 1:
                        
                        System.out.println("Has seleccionado el menu coche");
                        menuCoche(concesionario);
                        
                        
                        break;
                    
                        
                        case 2:
                        
                        menuXSD();
                        
                        
                        break;
                    case 3:
                        menuDTD();
                        break;
                        
                       
                        case 4:
                        
                        System.out.println("Has seleccionado introducir sentencia xpath");
                        menuXPath();
                        
                        
                        
                        break;
                        case 5:
                        
                        System.out.println("Has elegido hacer una consulta con XQuery");
                        System.out.println("Introduzca el nombre del fichero. En caso de no tener, introduzca`consulta` y "
                                + "se listaran las marcas de los coches que hay actualmente en el concesionario");
                        Scanner entradaEscaner4 = new Scanner (System.in);
                        String fileXQ = entradaEscaner4.nextLine ();
                        Xquery consulta = new Xquery();
                        consulta.xquery(fileXQ);
                        break;
                        
                        
                        
                                
                        case 6:
                        menuWellFormed();
                        break;
                        
                    case 7:
                        MarshUnmarsh marsh=new MarshUnmarsh();
                        concesionario.setCoches(coches);
                        marsh.marshallConcesionario(concesionario);
                        System.out.println("el concesionario ha sido guardado");
                            break;
                    case 8:
                        salir = true;
                        break;
                        
                    default:
                        System.out.println("Solo números entre 1 y 8");
                }
            } catch (InputMismatchException e) {
                System.out.println("Debes insertar un número");
                sn.next();
            }
        }
 
    }
    
     
    
    public void menuCoche(Concesionario concesionario){
        ArrayList<Coche> coches=concesionario.getCoches();
        
        Scanner sn = new Scanner(System.in);
        boolean salir = false;
        int opcion; //Guardaremos la opcion del usuario
 
        while (!salir) {
 
            System.out.println("1. cargar un coche de xml");
            System.out.println("2. añadir un coche al concesionario");
            System.out.println("3. guardar un coche del concesionario");
            System.out.println("4. Atrás");
 
            try {
  
  
                System.out.println("Escribe una de las opciones");
                opcion = sn.nextInt();
 
                switch (opcion) {
                    case 1:
                        
                        System.out.println("Has seleccionado cargar coche");
                        System.out.println ("Por favor introduzca el id:(si no ha introducido ningun coche aún, "
                                + "introduzca 0)");
                        Scanner entradaEscaner = new Scanner (System.in); 
                        MarshUnmarsh unmarsh=new MarshUnmarsh();
                        
                        
                        Integer id = Integer.parseInt(entradaEscaner.nextLine ());
                        Coche coche=unmarsh.unmarshallCoche(id);
                        coches.add(coche);
                        System.out.println ("el coche ha sido introducido en el concesionario");
                        System.out.println (coche);
                        break;
                        
                        
                    case 2:
                        System.out.println("Has seleccionado añadir un coche al concesionario");
                        
                        Coche coche2=new Coche();
                        System.out.println ("Por favor introduzca el id");
                        Scanner entradaEscaner4 = new Scanner (System.in);
                        Integer id2=Integer.parseInt(entradaEscaner4.nextLine ());
                        coche2.setId(id2);
                        System.out.println("introduzca la marca");
                        
                        String marca = entradaEscaner4.nextLine ();
                        coche2.setMarca(marca);
                        System.out.println ("Por favor introduzca el modelo");
                        
                        String modelo=entradaEscaner4.nextLine();
                        coche2.setModelo(modelo);
                        System.out.println ("Por favor introduzca el color");
                        
                        String color=entradaEscaner4.nextLine();
                        coche2.setColor(color);
                        coches.add(coche2);
                        System.err.println(coches.get(0).getMarca());
                        
                        System.out.println ();
                        
                        
                        
                        break;
                    case 3:
                        System.out.println(concesionario.getCoches());
                        if (coches.isEmpty()) {
                            System.out.println("No hay ningún coche en el concesionario");
                            break;
                        }
                        System.out.println("Has elegido exportar un coche");
                        System.out.println("Introduzca el id del coche a exportar: ");
                        int numero1 = sn.nextInt();
                        for (int i = 0; i < coches.size(); i++) {
                            System.out.println(coches.get(i).getId());
                            if (coches.get(i).getId() == numero1) {
                                Coche cocheNuevo = coches.get(i);
                                System.out.println(cocheNuevo.getId() + "\n" + cocheNuevo.getId() + "\n"
                                        + cocheNuevo.getMarca() + "\n" + cocheNuevo.getModelo() + "\n" + cocheNuevo.getColor()+"\n");
                                MarshUnmarsh coche3 = new MarshUnmarsh();
                               
                                
                                coche3.marshallCoche(cocheNuevo);
                                break;
                            }
                        }

                        break;
                    case 4:
                        salir = true;
                        break;
                        
                    default:
                        System.out.println("Solo números entre 1 y 4");
                }
            } catch (InputMismatchException e) {
                System.out.println("Debes insertar un número");
                sn.next();
            }
        }   
    }
    
    
    
    
    public void menuDTD(){
System.out.println("Has seleccionado la validacion por dtd");
                        System.out.println ("Por favor introduzca el nombre del nombre del xml:");
                        Scanner entradaEscaner4 = new Scanner (System.in);  
                        CheckWithDTD check3=new CheckWithDTD();
                        String nombre3 = entradaEscaner4.nextLine (); 
                        System.out.println ("Por favor introduzca el nombre del nombre del dtd:");
                        Scanner entradaEscaner5 = new Scanner (System.in);
                        String dtd=entradaEscaner5.nextLine();
                        System.out.println (check3.checkWithDTD(nombre3,dtd));
}
    
    public void menuXSD(){
        System.out.println("Has seleccionado validacion por xsd");
                        System.out.println ("Por favor introduzca el nombre del nombre del xml:");
                        Scanner entradaEscaner2 = new Scanner (System.in);  
                        CheckWithXSD check2=new CheckWithXSD();
                        String nombre2 = entradaEscaner2.nextLine (); 
                        System.out.println ("Por favor introduzca el nombre del nombre del xsd:");
                        Scanner entradaEscaner3 = new Scanner (System.in);
                        String xsd=entradaEscaner3.nextLine();
                        System.out.println (check2.checkWithXSD(nombre2,xsd));
    }
    
    public void menuXPath(){
         System.out.println("Has seleccionado consulta xpath");
         System.out.println ("Por favor introduzca el nombre del concesionario. si no tiene use ´prueba´:");
         Scanner entradaEscaner2 = new Scanner (System.in); 
         Xpath xpath=new Xpath();
         String nombre2 = entradaEscaner2.nextLine (); 
         System.out.println ("introduzca la sentencia(ej: count(//Coche) para ver cuantos coches tiene el concesionario):");
          Scanner entradaEscaner3 = new Scanner (System.in);
          String sentencia=entradaEscaner3.nextLine();
         System.out.println("el concesionario tiene "+ xpath.xpath(nombre2, sentencia)+" coches");
        
    }
    
   
    public void menuWellFormed(){
        System.out.println("Has seleccionado la chequeo well formed");
                        System.out.println ("Por favor introduzca el nombre del fichero(si no tiene, introduzca prueba):");

                        

                        Scanner entradaEscaner6 = new Scanner (System.in); 
                        CheckWellFormedXML check=new CheckWellFormedXML();
                        String nombre4 = entradaEscaner6.nextLine (); 
                        System.out.println (check.checkWellFormed(nombre4));
        
    }
}
 
    
     


