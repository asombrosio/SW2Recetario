/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sw2;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.xml.sax.SAXException;

/**
 *
 * @author ebenz
 */
public class CheckWithDTD {
    
    public String checkWithDTD(String nombre, String dtd){
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.XML_DTD_NS_URI);
            Schema schema = schemaFactory.newSchema(new File(dtd+".dtd"));
            Validator validator = schema.newValidator();
            validator.validate(new StreamSource(nombre+".xml"));
            return "es valido";
            
        } catch (SAXException | IOException ex) {
            Logger.getLogger(CheckWithDTD.class.getName()).log(Level.SEVERE, null, ex);
        }
        
         return "ha habido un error";

    }
    
}
