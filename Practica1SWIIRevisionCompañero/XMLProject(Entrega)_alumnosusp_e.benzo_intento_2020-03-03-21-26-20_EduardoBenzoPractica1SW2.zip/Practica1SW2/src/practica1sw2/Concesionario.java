/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sw2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ebenz
 */

@XmlAccessorType (XmlAccessType.FIELD)
@XmlRootElement(name="Concesionario")


public class Concesionario implements Serializable {
    
    @XmlElement
    private String nombre;
    @XmlElement
    private String localizacion;
    @XmlElement
    private String encargado;
    @XmlElement(name = "Coche")
    @XmlElementWrapper(name = "Coches")
    private ArrayList<Coche> coches;

    public Concesionario() {
        coches=new ArrayList();
    }

    public void setCoches(ArrayList<Coche> coches) {
        this.coches = coches;
    }

    
public ArrayList<Coche> getCoches() {
        return coches;
    }
    

    public String getNombre() {
        return nombre;
    }

    public String getLocalizacion() {
        return localizacion;
    }

    public String getEncargado() {
        return encargado;
    }

    

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setLocalizacion(String localizacion) {
        this.localizacion = localizacion;
    }

    public void setEncargado(String encargado) {
        this.encargado = encargado;
    }
    
    
    
    
}
