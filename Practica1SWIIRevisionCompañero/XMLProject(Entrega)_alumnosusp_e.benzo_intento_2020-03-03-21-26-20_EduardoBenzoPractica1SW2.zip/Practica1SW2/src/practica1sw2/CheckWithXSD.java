/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1sw2;

import java.io.File;
import java.io.IOException;
import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.xml.sax.SAXException;

/**
 *
 * @author ebenz
 */
public class CheckWithXSD {

    

    public CheckWithXSD() {
    }
    
        public String checkWithXSD(String nombre, String xsd) {
            String path =nombre+".xml";
            File schemaFile = new File(xsd+".xsd");
            Source xmlFile = new StreamSource(new File(nombre+".xml"));
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            try {
                Schema schema = schemaFactory.newSchema(schemaFile);
                Validator validator = schema.newValidator();
                validator.validate(xmlFile);
                return (xmlFile.getSystemId() + " is valid");
            } catch (SAXException e) {
                return (xmlFile.getSystemId() + " is NOT valid reason:" + e);
            } catch (IOException e) {}
            return "ha habido un error";
            
        

    

        }
}